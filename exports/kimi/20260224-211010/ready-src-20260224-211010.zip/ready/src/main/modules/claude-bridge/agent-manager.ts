import { spawn, spawnSync, ChildProcess } from 'child_process'
import { EventEmitter } from 'events'
import { WorktreePool } from './worktree-pool'

export interface AgentInstance {
  name: string
  process: ChildProcess
  worktree: string
  status: 'idle' | 'working' | 'done' | 'error'
  task?: string
}

export interface AgentOutput {
  agent: string
  chunk: string
  type: 'stdout' | 'stderr' | 'error'
}

export class AgentManager extends EventEmitter {
  private agents = new Map<string, AgentInstance>()
  private worktreePool: WorktreePool
  private maxAgents = 4
  private useMock: boolean

  constructor(useMock = false) {
    super()
    this.useMock = useMock
    this.worktreePool = new WorktreePool(useMock)
  }

  /**
   * Spawn a new Agent (Claude Code instance)
   */
  async spawnAgent(name: string, task: string): Promise<boolean> {
    // Check agent limit
    if (this.agents.size >= this.maxAgents) {
      this.emit('output', {
        agent: name,
        chunk: `Error: Maximum agent limit (${this.maxAgents}) reached. Please wait for existing agents to complete.`,
        type: 'error'
      })
      return false
    }

    // Check if agent already exists
    if (this.agents.has(name)) {
      this.killAgent(name)
    }

    try {
      // Acquire worktree
      const wt = await this.worktreePool.acquire(name)

      // Spawn Claude Code process
      const proc = this.useMock 
        ? this.createMockProcess(task)
        : this.createClaudeProcess(wt.path, task)

      const agent: AgentInstance = {
        name,
        process: proc,
        worktree: wt.path,
        status: 'working',
        task
      }

      this.agents.set(name, agent)
      this.emit('status', { agent: name, status: 'working' })

      // Handle process output
      proc.stdout?.on('data', (chunk: Buffer) => {
        this.emit('output', {
          agent: name,
          chunk: chunk.toString(),
          type: 'stdout'
        })
      })

      proc.stderr?.on('data', (chunk: Buffer) => {
        this.emit('output', {
          agent: name,
          chunk: chunk.toString(),
          type: 'stderr'
        })
      })

      proc.on('close', (code) => {
        const status = code === 0 ? 'done' : 'error'
        agent.status = status
        this.emit('status', { agent: name, status })
        this.agents.delete(name)
        this.worktreePool.release(wt.path).catch(console.error)
      })

      proc.on('error', (error) => {
        agent.status = 'error'
        this.emit('output', {
          agent: name,
          chunk: `Process error: ${error.message}`,
          type: 'error'
        })
        this.emit('status', { agent: name, status: 'error' })
        this.agents.delete(name)
        this.worktreePool.release(wt.path).catch(console.error)
      })

      return true
    } catch (error) {
      const errorMessage = error instanceof Error ? error.message : String(error)
      this.emit('output', {
        agent: name,
        chunk: `Failed to spawn agent: ${errorMessage}`,
        type: 'error'
      })
      return false
    }
  }

  /**
   * Create Claude Code process
   */
  private createClaudeProcess(worktreePath: string, task: string): ChildProcess {
    // Check if Claude Code CLI is available
    const claudeAvailable = this.isClaudeAvailable()

    if (!claudeAvailable) {
      // Fallback to mock process
      return this.createMockProcess(task)
    }

    // Real Claude Code process
    const proc = spawn(
      'claude',
      ['--print', '--output-format', 'stream-json'],
      {
        cwd: worktreePath,
        env: {
          ...process.env,
          CLAUDE_CODE_EXPERIMENTAL_AGENT_TEAMS: '1'
        }
      }
    )

    // Send task via stdin
    proc.stdin?.write(task)
    proc.stdin?.end()

    return proc
  }

  /**
   * Check if Claude CLI is available
   */
  private isClaudeAvailable(): boolean {
    try {
      const result = spawnSync('claude', ['--version'], { stdio: 'ignore' })
      return result.status === 0
    } catch {
      return false
    }
  }

  /**
   * Create mock process for cloud environment
   */
  private createMockProcess(task: string): ChildProcess {
    const script = `
const task = ${JSON.stringify(task)};
console.log('[Mock Agent] Received task: ' + task);
console.log('[Mock Agent] Claude Code is not available in this environment.');
console.log('[Mock Agent] This is a mock response for testing UI.');
`

    return spawn(process.execPath, ['-e', script], {
      stdio: ['pipe', 'pipe', 'pipe']
    })
  }

  /**
   * Orchestrate multiple agents for a task
   */
  async orchestrate(task: string, agentNames?: string[]): Promise<boolean> {
    const agents = agentNames || ['butler']

    // Spawn butler agent first to analyze task
    const butlerSpawned = await this.spawnAgent('butler', `Analyze and orchestrate this task: ${task}`)

    if (!butlerSpawned) {
      return false
    }

    // Listen for butler output to spawn sub-agents
    const onOutput = (data: AgentOutput) => {
      if (data.agent === 'butler' && data.type === 'stdout') {
        // Parse butler output for sub-agent spawn commands
        // Format: SPAWN_AGENT:<name>:<task>
        const match = data.chunk.match(/SPAWN_AGENT:(\w+):(.+)/)
        if (match) {
          const [, agentName, agentTask] = match
          if (agents.includes(agentName)) {
            this.spawnAgent(agentName, agentTask)
          }
        }
      }
    }

    this.on('output', onOutput)

    // Clean up listener after 5 minutes
    setTimeout(() => {
      this.off('output', onOutput)
    }, 5 * 60 * 1000)

    return true
  }

  /**
   * Get agent status
   */
  getAgentStatus(name: string): AgentInstance | undefined {
    return this.agents.get(name)
  }

  /**
   * Get all active agents
   */
  getAllAgents(): AgentInstance[] {
    return Array.from(this.agents.values())
  }

  /**
   * Kill an agent
   */
  killAgent(name: string): boolean {
    const agent = this.agents.get(name)
    if (agent) {
      agent.process.kill()
      this.agents.delete(name)
      return true
    }
    return false
  }

  /**
   * Cleanup all agents
   */
  cleanup(): void {
    for (const [name, agent] of this.agents) {
      try {
        agent.process.kill()
        this.worktreePool.release(agent.worktree).catch(console.error)
      } catch (error) {
        console.error(`Failed to cleanup agent ${name}:`, error)
      }
    }
    this.agents.clear()
  }
}
