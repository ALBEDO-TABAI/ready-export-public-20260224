import { ipcMain } from 'electron'
import { readFileSync, writeFileSync, readdirSync, statSync, existsSync } from 'fs'
import { join } from 'path'

export function setupDocumentIPC(useMock = false): void {
  // Read file
  ipcMain.handle('document:read', async (_, path: string) => {
    try {
      if (useMock) {
        return { 
          success: true, 
          content: `[Mock] Content of ${path}`,
          mock: true 
        }
      }
      
      if (!existsSync(path)) {
        return { success: false, error: 'File not found' }
      }

      const content = readFileSync(path, 'utf-8')
      return { success: true, content }
    } catch (error) {
      const errorMessage = error instanceof Error ? error.message : String(error)
      return { success: false, error: errorMessage }
    }
  })

  // Write file
  ipcMain.handle('document:write', async (_, { path, content }: { path: string; content: string }) => {
    try {
      if (useMock) {
        return { success: true, mock: true }
      }
      
      writeFileSync(path, content, 'utf-8')
      return { success: true }
    } catch (error) {
      const errorMessage = error instanceof Error ? error.message : String(error)
      return { success: false, error: errorMessage }
    }
  })

  // List directory
  ipcMain.handle('document:list', async (_, dir: string) => {
    try {
      if (useMock) {
        return { 
          success: true, 
          items: [
            { name: 'documents', path: `${dir}/documents`, isDirectory: true, size: 0, modified: new Date() },
            { name: 'images', path: `${dir}/images`, isDirectory: true, size: 0, modified: new Date() },
            { name: 'readme.md', path: `${dir}/readme.md`, isDirectory: false, size: 1024, modified: new Date() }
          ],
          mock: true 
        }
      }
      
      if (!existsSync(dir)) {
        return { success: false, error: 'Directory not found' }
      }

      const items = readdirSync(dir).map(name => {
        const path = join(dir, name)
        const stats = statSync(path)
        return {
          name,
          path,
          isDirectory: stats.isDirectory(),
          size: stats.size,
          modified: stats.mtime
        }
      })

      return { success: true, items }
    } catch (error) {
      const errorMessage = error instanceof Error ? error.message : String(error)
      return { success: false, error: errorMessage }
    }
  })

  // Parse docx (placeholder - requires mammoth)
  ipcMain.handle('document:parseDocx', async (_, path: string) => {
    try {
      // Cloud fallback: Return mock data
      return { 
        success: true, 
        content: '<p>[Mock] DOCX parsing requires mammoth.js</p><p>File: ' + path + '</p>',
        html: '<p>[Mock] DOCX parsing requires mammoth.js</p>',
        mock: true
      }
    } catch (error) {
      const errorMessage = error instanceof Error ? error.message : String(error)
      return { success: false, error: errorMessage }
    }
  })

  // Parse xlsx (placeholder - requires SheetJS)
  ipcMain.handle('document:parseXlsx', async (_, path: string) => {
    try {
      // Cloud fallback: Return mock data
      return { 
        success: true, 
        sheets: ['Sheet1'],
        data: { 'Sheet1': [['A1', 'B1'], ['A2', 'B2']] },
        file: path,
        mock: true
      }
    } catch (error) {
      const errorMessage = error instanceof Error ? error.message : String(error)
      return { success: false, error: errorMessage }
    }
  })
}
