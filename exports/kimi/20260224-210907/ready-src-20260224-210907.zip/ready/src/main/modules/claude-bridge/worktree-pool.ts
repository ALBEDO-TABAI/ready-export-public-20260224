import { execSync } from 'child_process'
import { mkdirSync, existsSync, copyFileSync, writeFileSync } from 'fs'
import { join } from 'path'
import { app } from 'electron'

export interface Worktree {
  path: string
  branch: string
  agentName: string
}

export class WorktreePool {
  private basePath: string
  private worktreesDir: string
  private agentsDir: string
  private activeWorktrees = new Map<string, Worktree>()
  private useMock: boolean

  constructor(useMock = false) {
    this.useMock = useMock
    
    try {
      this.basePath = app.getPath('userData')
    } catch {
      // Fallback for test environment
      this.basePath = join(process.cwd(), '.ready-data')
    }
    
    this.worktreesDir = join(this.basePath, '.worktrees')
    this.agentsDir = join(this.basePath, 'agents')

    this.ensureDirectories()
    
    if (!this.useMock) {
      this.initGitRepo()
    }
  }

  private ensureDirectories(): void {
    if (!existsSync(this.worktreesDir)) {
      mkdirSync(this.worktreesDir, { recursive: true })
    }
    if (!existsSync(this.agentsDir)) {
      mkdirSync(this.agentsDir, { recursive: true })
    }
  }

  private initGitRepo(): void {
    const gitDir = join(this.basePath, '.git')
    if (!existsSync(gitDir)) {
      try {
        execSync('git init', { cwd: this.basePath, stdio: 'ignore' })
        execSync('git config user.email "ready@localhost"', { cwd: this.basePath, stdio: 'ignore' })
        execSync('git config user.name "Ready"', { cwd: this.basePath, stdio: 'ignore' })
      } catch (error) {
        console.warn('Git init failed (non-fatal):', error)
      }
    }
  }

  /**
   * Acquire a new worktree for an agent
   */
  async acquire(agentName: string): Promise<Worktree> {
    const taskId = Date.now()
    const branch = `agent/${agentName}-${taskId}`
    const path = join(this.worktreesDir, `${agentName}-${taskId}`)

    if (!this.useMock) {
      try {
        // Create worktree using git
        execSync(`git worktree add "${path}" -b ${branch}`, {
          cwd: this.basePath,
          stdio: 'ignore'
        })
      } catch (error) {
        // Fallback: Just create directory if git worktree fails
        console.warn('Git worktree failed, using directory fallback:', error)
        mkdirSync(path, { recursive: true })
      }
    } else {
      // Mock mode: just create directory
      mkdirSync(path, { recursive: true })
    }

    // Copy agent's CLAUDE.md to worktree
    this.copyAgentConfig(agentName, path)

    const worktree: Worktree = { path, branch, agentName }
    this.activeWorktrees.set(path, worktree)

    return worktree
  }

  /**
   * Copy agent configuration to worktree
   */
  private copyAgentConfig(agentName: string, worktreePath: string): void {
    const agentDir = join(this.agentsDir, agentName)
    const claudeMdSource = join(agentDir, 'CLAUDE.md')
    const claudeMdDest = join(worktreePath, 'CLAUDE.md')

    // Create default CLAUDE.md if agent doesn't have one
    if (!existsSync(claudeMdSource)) {
      this.createDefaultAgentConfig(agentName, agentDir)
    }

    // Copy CLAUDE.md to worktree
    if (existsSync(claudeMdSource)) {
      try {
        copyFileSync(claudeMdSource, claudeMdDest)
      } catch (error) {
        console.warn('Failed to copy CLAUDE.md:', error)
      }
    }
  }

  /**
   * Create default agent configuration
   */
  private createDefaultAgentConfig(agentName: string, agentDir: string): void {
    if (!existsSync(agentDir)) {
      mkdirSync(agentDir, { recursive: true })
    }

    const personaContent = this.getDefaultPersona(agentName)
    const claudeMdPath = join(agentDir, 'CLAUDE.md')

    try {
      writeFileSync(claudeMdPath, personaContent, 'utf-8')
    } catch (error) {
      console.warn('Failed to create default agent config:', error)
    }
  }

  /**
   * Get default persona for agent type
   */
  private getDefaultPersona(agentName: string): string {
    const personas: Record<string, string> = {
      butler: `# Butler Agent - 管家

你是 Ready 工作台的管家 Agent，负责协调和编排其他 Agent。

## 职责
- 理解用户需求并拆解任务
- 协调文案、剪辑、分析等 Agent 并行工作
- 汇总结果并返回给用户

## 行为准则
- 温和耐心，像一位专业管家
- 先分析再行动，不盲目执行
- 及时汇报进度和结果
`,
      copywriter: `# Copywriter Agent - 文案

你是 Ready 工作台的文案 Agent，专注于自媒体内容创作。

## 职责
- 撰写标题、文案、脚本
- 优化内容结构和节奏
- 适配不同平台风格

## 行为准则
- 追求节奏感和传播力
- 了解各平台调性差异
- 善于捕捉热点和痛点
`,
      'video-editor': `# Video Editor Agent - 剪辑

你是 Ready 工作台的剪辑 Agent，专注于视频内容制作。

## 职责
- 分析视频素材并提取精华
- 自动剪辑和拼接
- 添加字幕和特效

## 行为准则
- 节奏明快，2秒内必须有切换
- 善用转场和音乐
- 注重开头3秒的吸引力
`,
      analyst: `# Analyst Agent - 分析

你是 Ready 工作台的分析 Agent，专注于数据和竞品研究。

## 职责
- 分析热门内容和趋势
- 研究竞品策略
- 提供数据洞察

## 行为准则
- 数据驱动，有理有据
- 关注可操作的建议
- 持续追踪和更新
`
    }

    return personas[agentName] || personas['butler']
  }

  /**
   * Release a worktree
   */
  async release(worktreePath: string): Promise<void> {
    const worktree = this.activeWorktrees.get(worktreePath)
    if (!worktree) return

    if (!this.useMock) {
      try {
        // Remove git worktree
        execSync(`git worktree remove "${worktreePath}" --force`, {
          cwd: this.basePath,
          stdio: 'ignore'
        })
      } catch (error) {
        console.warn('Git worktree remove failed:', error)
      }
    }

    this.activeWorktrees.delete(worktreePath)
  }

  /**
   * Get all active worktrees
   */
  getActiveWorktrees(): Worktree[] {
    return Array.from(this.activeWorktrees.values())
  }

  /**
   * Cleanup all worktrees
   */
  async cleanup(): Promise<void> {
    for (const [path] of this.activeWorktrees) {
      await this.release(path)
    }
  }
}
