import { ipcMain, BrowserWindow } from 'electron'
import { AgentManager } from './agent-manager'

export function setupAgentIPC(agentManager: AgentManager, mainWindow: BrowserWindow): void {
  // Send message to agent
  ipcMain.handle('agent:send', async (_, { agent, message }: { agent: string; message: string }) => {
    try {
      const success = await agentManager.spawnAgent(agent, message)
      return { success, error: success ? null : 'Failed to spawn agent' }
    } catch (error) {
      const errorMessage = error instanceof Error ? error.message : String(error)
      return { success: false, error: errorMessage }
    }
  })

  // Orchestrate multiple agents
  ipcMain.handle('agent:orchestrate', async (_, { task, agents }: { task: string; agents: string[] }) => {
    try {
      const success = await agentManager.orchestrate(task, agents)
      return { success, error: success ? null : 'Failed to orchestrate agents' }
    } catch (error) {
      const errorMessage = error instanceof Error ? error.message : String(error)
      return { success: false, error: errorMessage }
    }
  })

  // Get agent status
  ipcMain.handle('agent:getStatus', (_, agent: string) => {
    const status = agentManager.getAgentStatus(agent)
    return { status: status?.status || 'unknown', task: status?.task }
  })

  // Get all agents
  ipcMain.handle('agent:getAll', () => {
    return agentManager.getAllAgents().map(a => ({
      name: a.name,
      status: a.status,
      task: a.task
    }))
  })

  // Forward agent output to renderer
  agentManager.on('output', (data) => {
    if (!mainWindow.isDestroyed()) {
      mainWindow.webContents.send('agent:stream', data)
    }
  })

  // Forward agent status changes to renderer
  agentManager.on('status', (data) => {
    if (!mainWindow.isDestroyed()) {
      mainWindow.webContents.send('agent:status', data)
    }
  })
}
