import { ipcMain } from 'electron'
import { getDatabase } from '../database'

// Mock RSS data for cloud environment
const mockSources = [
  { id: '1', name: '36氪', url: 'https://36kr.com/feed', group: 'tech', enabled: true },
  { id: '2', name: '虎嗅', url: 'https://www.huxiu.com/rss', group: 'tech', enabled: true },
  { id: '3', name: '阮一峰', url: 'https://www.ruanyifeng.com/blog/atom.xml', group: 'dev', enabled: true }
]

const mockItems = [
  { 
    id: '1', 
    sourceId: '1', 
    title: 'AI 创作工具的下一个十年', 
    link: 'https://36kr.com/p/123456',
    summary: '探讨 AI 如何改变内容创作行业...',
    author: '张三',
    publishedAt: new Date(Date.now() - 3600000).toISOString(),
    read: false,
    starred: false
  },
  { 
    id: '2', 
    sourceId: '2', 
    title: '自媒体运营的核心方法论', 
    link: 'https://www.huxiu.com/article/789',
    summary: '从 0 到 1 打造个人 IP 的实战经验...',
    author: '李四',
    publishedAt: new Date(Date.now() - 7200000).toISOString(),
    read: false,
    starred: true
  },
  { 
    id: '3', 
    sourceId: '3', 
    title: '科技爱好者周刊', 
    link: 'https://www.ruanyifeng.com/blog/2026/02/weekly-300.html',
    summary: '本周值得关注的科技资讯...',
    author: '阮一峰',
    publishedAt: new Date(Date.now() - 86400000).toISOString(),
    read: true,
    starred: false
  }
]

export function setupRSSIPC(useMock = false): void {
  // Get all RSS sources
  ipcMain.handle('rss:getSources', async () => {
    try {
      if (useMock) {
        return { success: true, sources: mockSources, mock: true }
      }
      
      const db = getDatabase().getDatabase()
      if (db) {
        const sources = db.prepare('SELECT * FROM rss_sources WHERE enabled = 1').all()
        return { success: true, sources }
      }
      // Fallback to mock data
      return { success: true, sources: mockSources, mock: true }
    } catch (error) {
      return { success: true, sources: mockSources, mock: true }
    }
  })

  // Add RSS source
  ipcMain.handle('rss:addSource', async (_, source: { name: string; url: string; group?: string }) => {
    try {
      if (useMock) {
        return { success: true, id: `source-${Date.now()}`, mock: true }
      }
      
      const db = getDatabase().getDatabase()
      if (db) {
        const id = `source-${Date.now()}`
        db.prepare(
          'INSERT INTO rss_sources (id, name, url, group_name) VALUES (?, ?, ?, ?)'
        ).run(id, source.name, source.url, source.group || 'default')
        return { success: true, id }
      }
      return { success: false, error: 'Database not available' }
    } catch (error) {
      const errorMessage = error instanceof Error ? error.message : String(error)
      return { success: false, error: errorMessage }
    }
  })

  // Remove RSS source
  ipcMain.handle('rss:removeSource', async (_, id: string) => {
    try {
      if (useMock) {
        return { success: true, mock: true }
      }
      
      const db = getDatabase().getDatabase()
      if (db) {
        db.prepare('DELETE FROM rss_sources WHERE id = ?').run(id)
        return { success: true }
      }
      return { success: false, error: 'Database not available' }
    } catch (error) {
      const errorMessage = error instanceof Error ? error.message : String(error)
      return { success: false, error: errorMessage }
    }
  })

  // Get RSS items
  ipcMain.handle('rss:getItems', async (_, sourceId?: string) => {
    try {
      if (useMock) {
        const items = sourceId 
          ? mockItems.filter(i => i.sourceId === sourceId)
          : mockItems
        return { success: true, items, mock: true }
      }
      
      const db = getDatabase().getDatabase()
      if (db) {
        let items
        if (sourceId) {
          items = db.prepare('SELECT * FROM rss_items WHERE source_id = ? ORDER BY published_at DESC')
            .all(sourceId)
        } else {
          items = db.prepare('SELECT * FROM rss_items ORDER BY published_at DESC').all()
        }
        return { success: true, items }
      }
      // Fallback to mock data
      const items = sourceId 
        ? mockItems.filter(i => i.sourceId === sourceId)
        : mockItems
      return { success: true, items, mock: true }
    } catch (error) {
      return { success: true, items: mockItems, mock: true }
    }
  })

  // Mark item as read
  ipcMain.handle('rss:markRead', async (_, itemId: string) => {
    try {
      if (useMock) {
        return { success: true, mock: true }
      }
      
      const db = getDatabase().getDatabase()
      if (db) {
        db.prepare('UPDATE rss_items SET read = 1 WHERE id = ?').run(itemId)
        return { success: true }
      }
      return { success: false, error: 'Database not available' }
    } catch (error) {
      const errorMessage = error instanceof Error ? error.message : String(error)
      return { success: false, error: errorMessage }
    }
  })

  // Fetch all RSS feeds
  ipcMain.handle('rss:fetchAll', async () => {
    // Cloud fallback: Return mock success
    return { success: true, message: 'RSS fetch simulated (mock mode)', mock: true }
  })
}
