import { useState } from 'react'
import { Bold, Italic, Underline, Strikethrough, Link, Code, List, ListOrdered, CheckSquare, Quote, Type } from 'lucide-react'

export default function DocumentMode() {
  const [content, setContent] = useState(`# 欢迎使用 Ready 文档编辑器

这是一个支持 Markdown 的富文本编辑器。

## 功能特点

- **所见即所得**编辑体验
- 支持常见的 Markdown 语法
- AI 辅助写作
- 实时协作（未来版本）

## 快速开始

1. 点击左侧文件管理器创建新文档
2. 在编辑器中输入内容
3. 使用工具栏设置格式
4. 导出为 Markdown 或 Word 格式

> 💡 提示：使用 "/" 快速插入命令
`)

  const [activeFormats, setActiveFormats] = useState<string[]>([])

  const toggleFormat = (format: string) => {
    setActiveFormats(prev => 
      prev.includes(format) 
        ? prev.filter(f => f !== format)
        : [...prev, format]
    )
  }

  return (
    <div className="flex flex-col h-full">
      {/* Toolbar */}
      <div 
        className="h-[40px] flex items-center gap-1 px-3 border-b border-[var(--border-default)]"
        style={{ background: 'var(--bg-toolbar)' }}
      >
        {/* Text Style */}
        <div className="flex items-center gap-0.5">
          <button 
            onClick={() => toggleFormat('bold')}
            className={`p-1.5 rounded hover:bg-black/5 transition-colors ${activeFormats.includes('bold') ? 'bg-[var(--color-blue-light)] text-[var(--color-blue)]' : ''}`}
          >
            <Bold className="w-4 h-4" strokeWidth={2} />
          </button>
          <button 
            onClick={() => toggleFormat('italic')}
            className={`p-1.5 rounded hover:bg-black/5 transition-colors ${activeFormats.includes('italic') ? 'bg-[var(--color-blue-light)] text-[var(--color-blue)]' : ''}`}
          >
            <Italic className="w-4 h-4" strokeWidth={2} />
          </button>
          <button 
            onClick={() => toggleFormat('underline')}
            className={`p-1.5 rounded hover:bg-black/5 transition-colors ${activeFormats.includes('underline') ? 'bg-[var(--color-blue-light)] text-[var(--color-blue)]' : ''}`}
          >
            <Underline className="w-4 h-4" strokeWidth={2} />
          </button>
          <button 
            onClick={() => toggleFormat('strikethrough')}
            className={`p-1.5 rounded hover:bg-black/5 transition-colors ${activeFormats.includes('strikethrough') ? 'bg-[var(--color-blue-light)] text-[var(--color-blue)]' : ''}`}
          >
            <Strikethrough className="w-4 h-4" strokeWidth={2} />
          </button>
        </div>

        <div className="w-px h-5 bg-[var(--border-default)] mx-1" />

        {/* Lists */}
        <div className="flex items-center gap-0.5">
          <button className="p-1.5 rounded hover:bg-black/5 transition-colors">
            <List className="w-4 h-4" strokeWidth={2} />
          </button>
          <button className="p-1.5 rounded hover:bg-black/5 transition-colors">
            <ListOrdered className="w-4 h-4" strokeWidth={2} />
          </button>
          <button className="p-1.5 rounded hover:bg-black/5 transition-colors">
            <CheckSquare className="w-4 h-4" strokeWidth={2} />
          </button>
        </div>

        <div className="w-px h-5 bg-[var(--border-default)] mx-1" />

        {/* Insert */}
        <div className="flex items-center gap-0.5">
          <button className="p-1.5 rounded hover:bg-black/5 transition-colors">
            <Link className="w-4 h-4" strokeWidth={2} />
          </button>
          <button className="p-1.5 rounded hover:bg-black/5 transition-colors">
            <Code className="w-4 h-4" strokeWidth={2} />
          </button>
          <button className="p-1.5 rounded hover:bg-black/5 transition-colors">
            <Quote className="w-4 h-4" strokeWidth={2} />
          </button>
        </div>

        <div className="w-px h-5 bg-[var(--border-default)] mx-1" />

        {/* Headings */}
        <div className="flex items-center gap-0.5">
          <button className="px-2 py-1 rounded hover:bg-black/5 transition-colors text-[12px] font-bold">
            H1
          </button>
          <button className="px-2 py-1 rounded hover:bg-black/5 transition-colors text-[12px] font-semibold">
            H2
          </button>
          <button className="px-2 py-1 rounded hover:bg-black/5 transition-colors text-[12px] font-medium">
            H3
          </button>
        </div>
      </div>

      {/* Editor */}
      <div className="flex-1 overflow-auto">
        <div className="max-w-[800px] mx-auto p-8">
          <textarea
            value={content}
            onChange={(e) => setContent(e.target.value)}
            className="w-full min-h-[500px] resize-none bg-transparent border-none outline-none
              text-[15px] leading-relaxed text-[var(--text-body)] font-normal
              placeholder:text-[var(--text-placeholder)]"
            placeholder="开始输入..."
            spellCheck={false}
          />
        </div>
      </div>

      {/* Status Bar */}
      <div 
        className="h-[28px] flex items-center justify-between px-3 border-t border-[var(--border-default)] text-[11px] text-[var(--text-muted)]"
        style={{ background: 'var(--bg-toolbar)' }}
      >
        <div className="flex items-center gap-4">
          <span>Markdown 模式</span>
          <span>{content.length} 字符</span>
          <span>{content.split(/\s+/).filter(w => w.length > 0).length} 词</span>
        </div>
        <div className="flex items-center gap-4">
          <span>100%</span>
          <span>UTF-8</span>
        </div>
      </div>
    </div>
  )
}
