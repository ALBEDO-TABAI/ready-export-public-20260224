import { useState } from 'react'
import { ChevronRight, ChevronDown, FileText, Folder, Image, Film, FileSpreadsheet } from 'lucide-react'
import { useWorkspace } from '../../stores/useWorkspace'

interface FileTreeItemProps {
  item: {
    name: string
    path: string
    isDirectory: boolean
    size: number
  }
  depth?: number
}

function FileTreeItem({ item, depth = 0 }: FileTreeItemProps) {
  const [expanded, setExpanded] = useState(false)
  const { selectedFile, selectFile } = useWorkspace()

  const getIcon = () => {
    if (item.isDirectory) return <Folder className="w-4 h-4 text-[var(--color-blue)]" />
    const ext = item.name.split('.').pop()?.toLowerCase()
    switch (ext) {
      case 'md':
      case 'txt':
        return <FileText className="w-4 h-4 text-[var(--text-muted)]" />
      case 'png':
      case 'jpg':
      case 'jpeg':
        return <Image className="w-4 h-4 text-[var(--color-purple)]" />
      case 'mp4':
      case 'mov':
        return <Film className="w-4 h-4 text-[var(--color-orange)]" />
      case 'xlsx':
      case 'csv':
        return <FileSpreadsheet className="w-4 h-4 text-[var(--color-green)]" />
      default:
        return <FileText className="w-4 h-4 text-[var(--text-muted)]" />
    }
  }

  return (
    <div>
      <button
        onClick={() => {
          if (item.isDirectory) {
            setExpanded(!expanded)
          }
          selectFile(item.path)
        }}
        className={`
          w-full flex items-center gap-1.5 px-2 py-1 rounded-md text-[12px]
          transition-colors duration-200
          ${selectedFile === item.path ? 'bg-[var(--color-blue-light)] text-[var(--color-blue)]' : 'hover:bg-black/5'}
        `}
        style={{ paddingLeft: `${8 + depth * 16}px` }}
      >
        {item.isDirectory && (
          <span className="w-3 h-3 flex items-center justify-center">
            {expanded ? <ChevronDown className="w-3 h-3" /> : <ChevronRight className="w-3 h-3" />}
          </span>
        )}
        {!item.isDirectory && <span className="w-3" />}
        {getIcon()}
        <span className="truncate">{item.name}</span>
      </button>
      
      {expanded && item.isDirectory && (
        <div className="mt-0.5">
          <div 
            className="px-2 py-1 text-[11px] text-[var(--text-light)]"
            style={{ paddingLeft: `${8 + (depth + 1) * 16}px` }}
          >
            (空文件夹)
          </div>
        </div>
      )}
    </div>
  )
}

interface SidePanelProps {
  title?: string
  width?: number
}

export default function SidePanel({ title = '文件管理', width = 220 }: SidePanelProps) {
  const { files, sidebarVisible } = useWorkspace()

  if (!sidebarVisible) return null

  return (
    <div 
      className="flex-shrink-0 border-r border-[var(--border-default)] flex flex-col"
      style={{ width, background: 'var(--bg-panel)' }}
    >
      {/* Header */}
      <div className="h-[38px] flex items-center px-3 border-b border-[var(--border-default)]">
        <span className="text-[13px] font-semibold text-[var(--text-title)]">{title}</span>
        <span className="ml-2 px-1.5 py-0.5 rounded text-[10px] bg-[var(--color-green-light)] text-[var(--color-green)]">
          Connected
        </span>
      </div>

      {/* Search */}
      <div className="px-3 py-2">
        <input
          type="text"
          placeholder="搜索文件..."
          className="w-full px-3 py-1.5 rounded-[10px] text-[12px] border border-[var(--border-input)] bg-white
            placeholder:text-[var(--text-placeholder)]
            focus:outline-none focus:border-[var(--color-blue)] focus:ring-1 focus:ring-[var(--color-blue)]"
        />
      </div>

      {/* File Tree */}
      <div className="flex-1 overflow-auto px-2 pb-2">
        {files.length === 0 ? (
          <div className="flex flex-col items-center justify-center h-32 text-[var(--text-light)]">
            <Folder className="w-8 h-8 mb-2 opacity-50" />
            <span className="text-[11px]">暂无文件</span>
          </div>
        ) : (
          files.map((file) => (
            <FileTreeItem key={file.path} item={file} />
          ))
        )}
        
        {/* Mock folders */}
        <div className="mt-2">
          <div className="px-2 py-1 text-[10px] font-medium text-[var(--text-light)] uppercase tracking-wide">
            项目文件夹
          </div>
          {[
            { name: '视频素材', path: '/videos', isDirectory: true, size: 0 },
            { name: '文案输出', path: '/copy', isDirectory: true, size: 0 },
            { name: 'RSS数据', path: '/rss', isDirectory: true, size: 0 },
            { name: '设计系统', path: '/design', isDirectory: true, size: 0 }
          ].map((folder) => (
            <FileTreeItem key={folder.path} item={folder} />
          ))}
        </div>
      </div>
    </div>
  )
}
